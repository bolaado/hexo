% 单个脉冲序列生成函数   
function [x,n] = impseq(np,ns,nf)
% 产生 x(n) = delta(n-np); 
% np=脉冲信号施加的位置，
% ns=序列的起点位置， nf=序列的终点位置

% 检查输入参数正确性
if ((np < ns) | (np > nf) | (ns > nf))
    error('参数必须满足 ns <= np <= nf')
end

   n = [ns:nf]; % 生成位置向量
   x = [(n-np) == 0]; % 生成单个脉冲序列