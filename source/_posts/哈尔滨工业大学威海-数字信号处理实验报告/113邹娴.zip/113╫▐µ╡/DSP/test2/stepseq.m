% 阶跃序列生成函数
function [x,n] = stepseq(np,ns,nf)
% 产生 x(n) = u(n-np); ns <= n,np <= nf

% 检查输入参数正确性
if ((np < ns) | (ns > nf) | (np > nf)) 	
      error('参数必须满足 ns <= np <= nf')
end

n = [ns:nf]; % 生成位置向量
x = [(n-np) >= 0]; % 生成阶跃序列