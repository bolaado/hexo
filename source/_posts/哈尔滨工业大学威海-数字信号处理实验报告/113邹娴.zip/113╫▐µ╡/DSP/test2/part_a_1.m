M=32;
n=[0:M-1];
x = (n+1).*(stepseq(0,0,31)-stepseq(13,0,31))+(27-n).*(stepseq(13,0,31)-stepseq(27,0,31))+0*(stepseq(27,0,31)-stepseq(31,0,31))

k=[0:256];
X=x*(exp(-i*2*pi/256)).^(n'*k);
plot(k*(2/256),abs(X));
axis([0 2,0,200])
xlabel('\omega/\pi');
ylabel('|X(e^{j\omega})|');
title('X(e^{j\omega})');