function X=DTFT(x,M,N) %序列x，序列长M，频谱点数N
n=[0:M-1];
k=[0:N];
X=x*(exp(-i*2*pi/N)).^(n'*k);
end