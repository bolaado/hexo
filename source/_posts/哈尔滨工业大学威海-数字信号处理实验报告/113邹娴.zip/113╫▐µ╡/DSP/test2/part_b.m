M = 128;
P = 10;
n = [0:M-1];
x = (1/2).^n;
Y = DTFT(x,M,P);
y = abs(ifft(Y,P))
stem(y);
xlabel('n'); 
ylabel('y(n)');
title('y(n)');