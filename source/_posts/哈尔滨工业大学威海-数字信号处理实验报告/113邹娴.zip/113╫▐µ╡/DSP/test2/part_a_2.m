n = 0:31;
M = 32
N = 27;
k = 0:63
xn = (n+1).*(stepseq(0,0,31)-stepseq(13,0,31))+(27-n).*(stepseq(13,0,31)-stepseq(27,0,31))+0*(stepseq(27,0,31)-stepseq(31,0,31))
Xk = fft(xn,64);
figure
subplot(1,2,1)
stem(n,xn)
xlabel('n');
ylabel('xn');
title('x(n)');
subplot(1,2,2)
wk = 2*k/64;
stem(wk,abs(Xk))
title('IFFT[x(n)]');
xlabel('\omega/\pi');
ylabel('|X(e^j^\omega)|');


X32k=fft(xn,32);
x32n=ifft(X32k);
figure
subplot(1,2,1)
stem(n,x32n)
xlabel('n');
ylabel('xn');
title('x32(n)');

subplot(1,2,2)
k=0:M-1;
wk=2*k/M;
stem(wk,abs(X32k))
title('IFFT[x32(n)]');
xlabel('\omega/\pi');
ylabel('|X(e^j^\omega)|');



m=0:15;
X16k=X32k(1:2:32);
x16n=ifft(X16k);
figure
subplot(1,2,1)
stem(m,x16n)
xlabel('n');
ylabel('xn');
title('x16(n)');

subplot(1,2,2)
k=0:M/2-1;
wk=2*k/M;
stem(wk,abs(X16k))
title('IFFT[x16(n)]');
xlabel('\omega/\pi');
ylabel('|X(e^j^\omega)|');