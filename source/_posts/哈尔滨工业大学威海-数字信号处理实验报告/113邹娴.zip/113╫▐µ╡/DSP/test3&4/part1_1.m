%脉冲响应不变法
FS = 1 % 采样频率
[n,Wn] = buttord(0.1*2*pi*1, 0.25*2*pi*1, 3, 35, 's'); % 临界频率采用角频率表示 
[b,a] = butter(n, Wn, 's'); % 设计模拟的
[bz,az] = impinvar(b, a, FS); % 映射为数字的 
freqz(bz, az, 511, FS) 
title('脉冲响应不变法   T=1s')