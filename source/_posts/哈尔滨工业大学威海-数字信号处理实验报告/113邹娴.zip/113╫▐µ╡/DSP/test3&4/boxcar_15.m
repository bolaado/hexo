OmegaC=0.25*pi;
N=15;
M=1000;
b1=fir1(N,OmegaC/pi,boxcar(N+1));
figure,freqz(b1,1,M);
grid;
title('boxcar N=15');
n=0:1:N;
figure,h=stem(n,b1);
title('h(n)');

