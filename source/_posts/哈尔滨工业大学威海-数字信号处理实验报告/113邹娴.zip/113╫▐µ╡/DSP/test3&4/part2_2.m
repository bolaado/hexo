T = 0.2;
FS = 1/T; %采样频率
wp = 0.2*pi; 
ws = 0.5*pi; 
Rp = 3; % 通带衰减 
As = 35; % 阻带衰减 

% 频率预畸 
OmegaP = (2/T)*tan(wp/2); % Prewarp Prototype Passband freq 
OmegaS = (2/T)*tan(ws/2); % Prewarp Prototype Stopband freq
 
%设计butterworth低通滤波器原型 ——以下程序按公式编程，相当于（3）里面的buttord
N = ceil((log10((10^(Rp/10)-1)/(10^(As/10)-1)))/(2*log10(OmegaP/OmegaS))); %阶数N
OmegaC = OmegaP/((10^(Rp/10)-1)^(1/(2*N))); %3db截至频率
[z,p,k] = buttap(N); %获取零、极点、增益参数-相当于查表 
p = p*OmegaC; 
k = k*OmegaC^N; 
B = real(poly(z)); %poly( )函数通过根求原来多项式降幂排列时各项的系数，real函数复数的实数部分
b0 = k; 
cs = k*B; %分子
ds = real(poly(p));%分母 
% 双线性变换 
[b,a] = bilinear(cs, ds, FS); 
% 绘制结果 
freqz(b, a, 512, FS); 
title('双线性变换   T=0.2S');
