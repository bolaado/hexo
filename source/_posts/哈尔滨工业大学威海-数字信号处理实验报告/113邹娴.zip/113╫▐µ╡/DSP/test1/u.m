function u(t)
if t>0
    u = 1;
end