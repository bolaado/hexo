function DFT( x,M )
    n = 0:M-1;
    N = 64;
    k = -N:N; % 表示对频域X(ejω)采样N点
    w = (2.*pi/N).*k; %横坐标w
    c = x*(exp(-j*2*pi/N)).^(n'*k); % 此处x表示序列x(n)
    magX = abs(c); % 幅频响应 |X(ejω)|
    angX = angle(c); % 相频响应
    figure;
    plot(w/pi, magX); %横坐标w对pi归一化
    xlabel('w/pi');
    ylabel('|X(jw)|');
    title('信号x(n)的傅氏变换(|jw|)  fs=200Hz  '); % 1000 200 300
end