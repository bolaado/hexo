A = 44.128;
a = 50*1.414*3.14;
om0 = 50*1.414*3.14;
fs = 1000;
T = 1/fs;
n = 0:30;
t = 0:20;

xan = A.*(exp(-(a*n*T)).*sin(om0*n*T));
subplot(1, 2, 1)
ezplot('y=44.128.*(exp(-(50*1.414*3.14*t)).*sin(50*1.414*3.14*t))', [0,0.05,-5,19]);
xlabel('t');
ylabel('振幅');
subplot(1, 2, 2)
stem(n, xan);
xlabel('n');
ylabel('振幅');