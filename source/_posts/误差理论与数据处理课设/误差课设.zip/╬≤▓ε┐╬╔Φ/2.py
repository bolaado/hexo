from re import U
import xlrd
from xlrd.biffh import DATEFORMAT
import xlwt
import math
from xlutils.copy import copy


# 求和
def sum(data):
    sum_num = 0.0
    for i in data:
        sum_num += i
    return sum_num



#求平均值
def average(data):
    sum_num = 0.0
    for i in data:
        sum_num += i
    return sum_num / len(data)


# 求平方和
def squar(data):
    sum_num = 0.0
    for i in data:
        sum_num += i ** 2
    return sum_num


#求两数乘积和
def mul(data1, data2):
    sum_num = 0.0
    for i in range(len(data1)):
        sum_num += data1[i] * data2[i]
    return sum_num


if __name__ == "__main__":
    rb = xlrd.open_workbook('2.xlsx')
    sheet = rb.sheet_by_index(0)
    row1 = sheet.row_values(0)
    row2 = sheet.row_values(1)

    print(mul(row1, row2))
    print(sum(row1))
    print(sum(row2))
    h_xx = squar(row1) - sum(row1) ** 2 / len(row1)
    h_xy = mul(row1, row2) - sum(row1) * sum(row2) / len(row1)
    h_yy = squar(row2) - sum(row2) ** 2 / len(row2)

    # h_xx = float(('%.4f' % h_xx))
    # h_xy = float(('%.4f' % h_xy))
    # h_yy = float(('%.4f' % h_yy))

    print('h_xx', h_xx)
    print('h_xy', h_xy)
    print('h_yy', h_yy)

    b = h_xy / h_xx
    b0 = average(row2) - average(row1) * b

    # b = float(('%.4f'  % b))
    # b0 = float(('%.4f'  % b0))

    print("b=", b)
    print("b0=", b0)

    print("一元线性回归方程为：")
    print('y=', b0, '+', b, 'x')

    S = h_yy
    U = b * h_xy
    Q = S - U
    print(Q)

    F = (U/1) / (Q / (len(row1) - 2))
    if F >= 13.74: #a=0.01
        f_str = '线性回归效果高度显著'
    elif F >= 5.99: 
        f_str = '线性回归效果显著'
    elif F >= 3.78: 
        f_str = '线性回归效果显著但可信赖度不高'
    else: 
        f_str = '线性回归效果不明显'
    print(f_str)

    Sq = math.sqrt(Q / (len(row1) - 2))
    print("剩余标准差为：", Sq)

    wb = xlwt.Workbook()
    sheet1 = wb.add_sheet('sheet1')
    
    sheet1.write(0, 0, u'一元线性回归方程')
    sheet1.write(0, 1, 'y={}+{}x'.format(b0, b))
    sheet1.write(1, 0, f_str)
    sheet1.write(2, 0, u'剩余标准差')
    sheet1.write(2, 1, Sq)
    
    wb.save(u'结果.xls')