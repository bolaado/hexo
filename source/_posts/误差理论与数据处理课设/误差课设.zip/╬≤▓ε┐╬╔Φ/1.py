import xlrd
from xlrd.biffh import DATEFORMAT
import xlwt
import math
from xlutils.copy import copy


# 平均值
def average(data):
    sum_num = 0.0
    for i in data:
        sum_num += i
    return sum_num / len(data)
 
 
# 标准差
def variance(data):
    aver = average(data)
    sum_num = 0
    for i in data:
        sum_num += (i - aver) ** 2
    return math.sqrt(sum_num / len(data) / (len(data) - 1))


# 残差
def residual(data):
    b = []
    varian = variance(data)
    aver = average(data)
    for i in data:
        a = abs(i - aver)
        b.append(a)
    return b


# t分布
def t_distribution(data1, data2):
    rb2 = xlrd.open_workbook('分布表.xlsx')
    sheet2 = rb2.sheet_by_index(0)
    t = sheet2.cell(data1, data2).value
    return t


# 正态分布
def normal_distribution(data):
    if data == 95:
        t = 1.95
    return t


# 剔除最可能的粗大误差
def cheak1(data):
    while True:
        aver = average(data)
        resid = residual(data)
        max_value = max(resid)
        for i in data:
            if abs(i - aver) == max_value:
                b = i
                c = data.copy()
                data.remove(i)
        aver = average(data)
        varian = variance(data)
        t = t_distribution(len(data) - 2, 0)
        if max_value >= t * varian:
            d = data
            print("有粗大误差", b)
            continue
        else:
            d = c
            break         
    return d
 

#莱以特准则
def cheak2(data):
    while True:
        varian = variance(data)
        aver = average(data)
        length = len(data)
        for i in data:
            if abs(i - aver) > 3 * varian * math.sqrt(length):
                data.remove(i)
                break
        if len(data) == length:
            break
    return data


    
# 适用于线性系统（残差校核法）
def system_error1(data):
    aver = average(data)
    max_num = abs(data[0] - aver)
    for i in data:
        if max_num < abs(i - aver):
            max_num = abs(i - aver)
    sum1 = sum2 = 0
    for i in range(len(data) // 2 - 1):
        sum1 += abs(data[i] - aver)
    for i in range(len(data) // 2, len(data)):
        sum2 += abs(data[i] - aver)
    if abs(sum1 - sum2) >= max_num:
        return "测量中存在累进性系统误差！"
    else:
        return "测量中无累进性系统误差"
 
 
# 周期性系统误差判断(阿贝——赫梅特判别法)
def system_error2(data):
    aver = average(data)
    num = (variance(data) * math.sqrt(len(data))) ** 2
    sum_num = 0
    for i in range(len(data) - 1):
        sum_num += (data[i] - aver) * (data[i + 1] - aver)
    sum_num = abs(sum_num)
    if sum_num > num * math.sqrt(len(data) - 1):
        return "测量中存在周期性系统误差"
    else:
        return "测量中无周期性系统误差"


# 残差总和判别法
def system_error3(data):
    aver = average(data)
    varian = variance(data)
    sum_num = 0
    for i in range(len(data) - 1):
        sum_num += abs(data[i] - aver)
    if sum_num > 2 * varian * math.sqrt(len(data)):
        return "怀疑测量数据有系统误差"
    else:
        return "测量数据没有系统误差"



# 极限误差（置信概率95%）
def limit_error_normal(data):
    t = normal_distribution(95)
    limit_error = t * variance(data)   
    print("极限误差（正态分布）为：", limit_error)
    return limit_error


def limit_error_t(data):
    t = t_distribution(len(data) - 1, 0)
    limit_error = t * variance(data)
    print("极限误差（t分布）为：", limit_error)
    return limit_error


if __name__ == "__main__":
    rb = xlrd.open_workbook('1.xlsx')
    sheet = rb.sheet_by_index(0)
    rows = sheet.row_values(0)
    print(rows)

    # 粗大误差
    a = cheak1(rows)
    print("剔除粗大误差后：", a)
    b = cheak2(rows)
    print("剔除粗大误差后：", b)

    # 随机误差
    limit_error_normal(a)
    limit_error_t(a)

    # 系统误差
    print(system_error2(a))
    print(system_error3(a))

    wb = xlwt.Workbook()
    sheet1 = wb.add_sheet('sheet1')
    sheet2 = wb.add_sheet('sheet2')
    sheet1.write(0, 0, u'剔除粗大误差后数据')
    for j in range(len(a)):
        sheet1.write(0, j + 1, a[j])
    sheet1.write(1, 0, u'算数平均值')
    sheet1.write(1, 1, average(a))
    sheet1.write(2, 0, u'标准差')
    sheet1.write(2, 1, variance(a))
    sheet1.write(3, 0, u'极限误差（正态分布）')
    sheet1.write(3, 1, limit_error_normal(a))
    sheet1.write(4, 0, u'极限误差（t分布）')
    sheet1.write(4, 1, limit_error_t(a))
    sheet1.write(5, 0, system_error2(a))
    sheet1.write(6, 0, system_error3(a))
    
    sheet2.write(0, 0, u'剔除粗大误差后数据')
    for j in range(len(b)):
        sheet2.write(0, j + 1, b[j])
    sheet2.write(1, 0, u'算数平均值')
    sheet2.write(1, 1, average(b))
    sheet2.write(2, 0, u'标准差')
    sheet2.write(2, 1, variance(b))
    sheet2.write(3, 0, u'极限误差（正态分布）')
    sheet2.write(3, 1, limit_error_normal(b))
    sheet2.write(4, 0, u'极限误差（t分布）')
    sheet2.write(4, 1, limit_error_t(b))
    sheet2.write(5, 0, system_error2(b))
    sheet2.write(6, 0, system_error3(b))

    wb.save(u'测量结果.xls')
    
