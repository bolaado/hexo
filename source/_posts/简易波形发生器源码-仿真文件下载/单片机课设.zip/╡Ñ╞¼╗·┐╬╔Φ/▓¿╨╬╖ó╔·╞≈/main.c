#include "reg52.h"					   //����ͷ�ļ�

#define uchar unsigned char			   //�궨��
#define uint unsigned int
	

sbit KEY1=P2^1;
sbit KEY2=P2^2;
sbit KEY3=P2^3; 						   //���尴���Ľӿ�
sbit KEY4=P2^4;


sbit LED1=P0^0;
sbit LED2=P0^1;
sbit LED3=P0^2;
sbit LED4=P0^3;
sbit LED5=P0^4;
sbit LED6=P0^5;

sbit cs=P3^7;
bit flag=0;

unsigned char mode=0;//��������
unsigned char parameter=0;//��������

unsigned char StempValue=1;

unsigned char i=0;
unsigned char sqar_num=232;//ռ�ձ�Ϊ1:10
unsigned char num=0;


int amplitude=255;//���� 4.5V  0.5VΪ28
int duty=1;//ռ�ձ�

unsigned int temp=0;
unsigned char TIME0_H=0xff,TIME0_L=0xd9;
unsigned int FREQ=10000;//��ʼ��Ƶ��,50HZ

void delay(uint ten_us)	 //��ʱ����
{
	while(ten_us--);
}

void key_scan(void)
{
	if(KEY1==0)
	{	 
		delay(1000);
		if(KEY1==0)
		{
			while(!KEY1);
			
			if(mode>=3)
			{
				mode=0;
			}
			else 
			{
				mode++;
			}
		}
	}	
	
	if(KEY2==0)
	{
		delay(1000);
		if(KEY2==0)
		{
			parameter++;
			if(parameter>=3)
			{
				parameter=0;
			}
			switch(parameter)
			{
				case 0:	
					LED4=0;
					LED5=1;
					LED6=1;
					break;
				case 1:	
					LED4=1;
					LED5=0;
					LED6=1;
					break;
				case 2:	
					LED4=1;
					LED5=1;
					LED6=0;
					break;
			}
			while(!KEY2);
		}
	}
	
	if(KEY3==0)
	{	 
		delay(1000);
		if(KEY3==0)
		{
			switch(parameter)
			{
				case 0://Ƶ��
					FREQ++;
					if(mode==0|mode==2) 
					{
						//65336-10^6/(256*FREQ)
						temp=0xffff-3906/FREQ;  
						TIME0_H=temp/256;
						TIME0_L=temp%256;
					}
					else if(mode==1)
					{
						temp=0xffff-1953/FREQ;
						TIME0_H=temp/256;
						TIME0_L=temp%256;
					}

					break;
				case 1://����
					if(amplitude<255) 
					{
						amplitude+=28;
					}
					break;
				case 2://ռ�ձ�
					if(mode==0) 
					{
						if(duty<9) 
						{
							duty++;
							sqar_num-=24;//ռ�ձȽ�1:10
						}
						else
						{
							duty=9;
						}
					}
					break;
			}
			while(!KEY3);
		}
	}
	
	if(KEY4==0)
	{	 
		delay(1000);
		if(KEY4==0)
		{
			switch(parameter)
			{
				case 0://Ƶ��
					FREQ--;
					if(mode==0|mode==2)
					{
						
						temp=0xffff-3906/FREQ;
						TIME0_H=temp/256;
						TIME0_L=temp%256;
					}
					else if(mode==1)
					{
						temp=0xffff-1953/FREQ;
						TIME0_H=temp/256;
						TIME0_L=temp%256;
					}
				break;
				case 1://����
				{
					if(amplitude>0)
					{
						amplitude-=28;
					}
				}break;
				case 2://ռ�ձ�
				{
					if(mode==0)
					{
						if(duty>1)
						{
							duty--;
							sqar_num+=24;
						}
						else
						{
							duty=1;
						}
					}
					
				}break;
			}
			
			while(!KEY4);
		}
	} 
}

void intt0() interrupt 1
{
		switch(mode)
		{
			case 0 ://���� 
				TH0=TIME0_H;TL0=TIME0_L;
				if(i++<sqar_num)  
				{
					cs=0;
					P1=amplitude;
					cs=1;
				}
				else
				{
					cs=0;
					P1=0;
					cs=1;
				}
				LED1=0;
				LED2=1;
				LED3=1;
				break;
			case 1 ://���ǲ� 
				TH0=TIME0_H;TL0=TIME0_L;
				if(~flag)
				{
					cs=0;
					P1=num++;
					cs=1;
					if(num==0)
					{
						num=255;
						flag=1;
					}
				}
				else if(flag)
				{
					cs=0;
					P1=num--;
					cs=1;
					if(num==255)
					{
						num=1;
						flag=0;
					}
				} 
				LED1=1;
				LED2=0;
				LED3=1;
				break;
			case 2 ://��ݲ�
				TH0=TIME0_H;TL0=TIME0_L;
				cs=0;
				P1=num++;
				cs=1;
				LED1=1;
				LED2=1;
				LED3=0;
				break;
		}
  
  

}


void main(void)					 //������
{	
	TMOD=0X01;
	TH0=0xff;
	TL0=0xd9;
	ET0=1;//�򿪶�ʱ��0�ж�����
	EA=1;//�����ж�
	TR0=1;//�򿪶�ʱ��
	

	LED4=0;
	LED5=1;
	LED6=1;
	while(1)
	{

		key_scan();
		
//		switch(mode)
//		{
//			case 0 ://���� 
//				if(i++<sqar_num)  
//				{
//					cs=0;
//					P1=amplitude;
//					cs=1;
//				}
//				else
//				{
//					cs=0;
//					P1=0;
//					cs=1;
//				}
//				LED1=0;
//				LED2=1;
//				LED3=1;
//				break;
//			case 1 ://���ǲ� 
//				if(~flag)
//				{
//					cs=0;
//					P1=num++;
//					cs=1;
//					if(num==0)
//					{
//						num=255;
//						flag=1;
//					}
//				}
//				else if(flag)
//				{
//					cs=0;
//					P1=num--;
//					cs=1;
//					if(num==255)
//					{
//						num=1;
//						flag=0;
//					}
//				} 
//				LED1=1;
//				LED2=0;
//				LED3=1;
//				break;
//			case 2 ://��ݲ�
//				cs=0;
//				P1=num++;
//				cs=1;
//				LED1=1;
//				LED2=1;
//				LED3=0;
//				break;
//		}
//		delay(fs);
	}
}
